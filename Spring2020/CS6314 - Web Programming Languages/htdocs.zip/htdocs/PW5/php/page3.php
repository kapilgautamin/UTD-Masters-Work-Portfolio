<?
session_start();
echo "Hello<br>";
if(isset($_SESSION["username"])){
	echo "Welcome $_SESSION['username']";
} else {
	echo "Welcome Guest";
}

?>
