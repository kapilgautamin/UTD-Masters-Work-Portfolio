<?
session_destroy();

//session_start();
echo "session " . $_SESSION["usr"];

?>