#include "Renderer.h"

int main(int argc, char* argv[]) {
	Renderer m_renderer;
	m_renderer.run();
	return EXIT_SUCCESS;
}