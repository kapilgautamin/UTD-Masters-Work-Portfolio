#include "Renderer.h"

int main() {
	Renderer m_renderer;
	m_renderer.run();
	return EXIT_SUCCESS;
}